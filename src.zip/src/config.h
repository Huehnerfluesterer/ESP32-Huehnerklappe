#pragma once

// =====================================================
// KONFIGURATIONSDATEI – ZUGANGSDATEN
// =====================================================
// WICHTIG: Diese Datei enthält geheime Zugangsdaten.
//          Trage sie in deine .gitignore ein!
//
//  .gitignore Eintrag:
//      src/config.h
// =====================================================

#define WIFI_SSID     "Wildsau"
#define WIFI_PASSWORD "19690610"

// =====================================================
// TELEGRAM PUSH-NACHRICHTEN
// =====================================================
// Telegram wird jetzt komplett im WebUI konfiguriert:
//   Erweitert → 📱 Telegram
// Einstellungen werden im EEPROM persistiert.
// =====================================================
