#pragma once

// =====================================================
// KONFIGURATIONSDATEI – ZUGANGSDATEN
// =====================================================
// WICHTIG: Diese Datei enthält geheime Zugangsdaten.
//          Trage sie in deine .gitignore ein!
//
//  .gitignore Eintrag:
//      src/config.h
// =====================================================

#define WIFI_SSID     "Wildsau"
#define WIFI_PASSWORD "19690610"

// =====================================================
// TELEGRAM PUSH-NACHRICHTEN
// =====================================================
// 1. In Telegram @BotFather schreiben → /newbot
// 2. Bot-Token eintragen (Format: 123456789:ABCdef...)
// 3. Bot anschreiben → @userinfobot für Chat-ID
// 4. TELEGRAM_ENABLED auf 1 setzen
// =====================================================
#define TELEGRAM_ENABLED  0                      // 0=aus, 1=ein
#define TELEGRAM_TOKEN    "DEIN_BOT_TOKEN_HIER"
#define TELEGRAM_CHAT_ID  "DEINE_CHAT_ID_HIER"

// Uhrzeit bis wann die Klappe geöffnet sein muss (sonst Alarm)
#define TELEGRAM_OPEN_DEADLINE_H  9   // 09:00 Uhr
#define TELEGRAM_OPEN_DEADLINE_M  0
