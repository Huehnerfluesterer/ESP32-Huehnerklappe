# 🐔 Hühnerklappe – Firmware

Automatische Hühnerklappe auf Basis des **ESP32-S3-DevKitC-1-N16R8**.

---

## Hardware

| Komponente | Typ / Wert |
|---|---|
| Mikrocontroller | ESP32-S3-DevKitC-1-N16R8 |
| Flash | 16 MB Quad-SPI |
| PSRAM | 8 MB Octal-SPI (OPI) |
| Motorsteuerung | L298N Dual H-Bridge |
| Motor | 12 V DC Getriebemotor |
| Licht-Sensor | VEML7700 (I²C) |
| Echtzeituhr | DS3231 (I²C) |
| Temperatursensor | BME280 (lokal I²C oder via ESP-NOW) |
| Stromsensor | ACS712-5A |
| RGB-LED-Kanal | 12 V, N-Kanal MOSFET IRLZ44N (4× PWM) |
| Relais Locklicht | 5 V, LOW-aktiv |
| Relais Stalllicht | 5 V, LOW-aktiv |
| Versorgung | 12 V DC → LM2596 5 V → onboard 3,3 V |

---

## Pin-Belegung ESP32-S3

> **Hinweis:** GPIO 26–37 sind beim N16R8 intern für Flash (26–32) und OPI-PSRAM (33–37) belegt.  
> GPIO 19/20 werden für die native USB-CDC genutzt.  
> Auf dem ESP32-S3 gibt es **keine input-only GPIOs** mehr – alle Pins unterstützen `INPUT_PULLUP`.

| Signal | GPIO | Anmerkung |
|--------|------|-----------|
| MOTOR_IN1 | 15 | L298N Richtung A (war ESP32: 25, existiert nicht auf S3) |
| MOTOR_IN2 | 11 | L298N Richtung B (war ESP32: 26) |
| MOTOR_ENA | 13 | L298N PWM Enable (war ESP32: 27) |
| RELAIS_PIN (Locklicht) | 18 | LOW-aktiv |
| STALLLIGHT_RELAY_PIN | 10 | LOW-aktiv (war ESP32: 19) |
| BUTTON_PIN (Klappe) | 39 | INPUT_PULLUP (war ESP32: 33) |
| STALL_BUTTON_PIN | 38 | INPUT_PULLUP (war ESP32: 32) |
| RED_BUTTON_PIN | 40 | INPUT_PULLUP, kein ext. R mehr nötig (war ESP32: 35) |
| ACS712_PIN (Analog) | 7 | ADC1_CH6 – WiFi-sicher (war ESP32: 34) |
| I2C SDA | 8 | VEML7700 + DS3231 (war ESP32: 21) |
| I2C SCL | 9 | VEML7700 + DS3231 (war ESP32: 22) |
| LIMIT_OPEN_PIN | 14 | Endschalter Öffnen |
| LIMIT_CLOSE_PIN | 12 | Endschalter Schließen |
| RGB_PIN_R | 4 | MOSFET Gate (470 Ω) |
| RGB_PIN_G | 16 | MOSFET Gate (470 Ω) |
| RGB_PIN_B | 17 | MOSFET Gate (470 Ω) |
| RGB_PIN_W | 23 | MOSFET Gate (470 Ω), optional |

---

## Migration ESP32 → ESP32-S3 (Änderungsprotokoll)

### GPIO-Remapping (Hardware anpassen!)

Folgende Pins am Steckbrett / auf der Platine müssen umgeklemmt werden:

| Funktion | Alt (ESP32) | Neu (ESP32-S3) | Grund |
|---|---|---|---|
| MOTOR_IN2 | GPIO 26 | GPIO 11 | Flash-Pin |
| MOTOR_ENA | GPIO 27 | GPIO 13 | Flash-Pin |
| Stalllicht-Relais | GPIO 19 | GPIO 10 | USB D– |
| Taster Klappe | GPIO 33 | GPIO 39 | Flash/PSRAM-Pin |
| Taster Stalllicht | GPIO 32 | GPIO 38 | Flash-Pin |
| Taster Rotlicht | GPIO 35 | GPIO 40 | PSRAM-Pin |
| ACS712 (Analog) | GPIO 34 | GPIO 7 | Flash-Pin, ADC1 bevorzugt |

### Schaltungsänderungen

- **R5 (10 kΩ Pull-up für Taster Rotlicht)** kann entfallen.  
  Auf dem ESP32-S3 hat GPIO 40 einen internen Pull-up (`INPUT_PULLUP`).  
  Der externe Widerstand schadet aber nicht, wenn er bereits verbaut ist.

### Software-Änderungen

| Datei | Änderung |
|---|---|
| `platformio.ini` | `board = esp32-s3-devkitc-1`, 16 MB Flash, OPI-PSRAM, USB-CDC |
| `src/pins.h` | Neue GPIO-Nummern (siehe Tabelle oben) |
| `src/motor.cpp` | LEDC-API 3.x: `ledcAttach(pin, freq, bits)` statt `ledcSetup` + `ledcAttachPin` |
| `src/light.cpp` | LEDC-API 3.x: `ledcAttach(pin, …)` + `ledcWrite(pin, …)` statt kanalbasierter API |

### LEDC-API (Arduino-ESP32 3.x)

```cpp
// Alt (Arduino-ESP32 2.x):
ledcSetup(channel, freq, bits);
ledcAttachPin(pin, channel);
ledcWrite(channel, duty);

// Neu (Arduino-ESP32 3.x):
ledcAttach(pin, freq, bits);
ledcWrite(pin, duty);
```

### Serieller Monitor / USB-CDC

Der ESP32-S3 hat eine **native USB-Schnittstelle**. Mit `-DARDUINO_USB_CDC_ON_BOOT=1` in `platformio.ini` erscheint der ESP32-S3 direkt als virtueller COM-Port – kein externer USB-UART-Adapter nötig.

Flash-Vorgang: `Ctrl+Alt+F` in PlatformIO, oder Boot-Taster (GPIO 0) halten und dann Reset drücken.

---

## Partitionstabelle

Durch die 16 MB Flash des N16R8 wird `default_16MB.csv` verwendet.  
Das gibt deutlich mehr Platz für Firmware (OTA) und LittleFS-Logs.

| Partition | Größe |
|---|---|
| nvs | 20 KB |
| app0 (OTA_0) | ~6,5 MB |
| app1 (OTA_1) | ~6,5 MB |
| spiffs/littlefs | ~1,5 MB |

---

## Flashen

```bash
# PlatformIO (VS Code Extension oder CLI)
pio run -t upload

# Bei Boot-Problemen: GPIO 0 gedrückt halten → Reset → loslassen
```

---

## Konfiguration

Zugangsdaten in `src/config.h` eintragen (nicht ins Git committen!):

```cpp
#define WIFI_SSID     "dein_ssid"
#define WIFI_PASSWORD "dein_passwort"
```

Die Datei ist in `.gitignore` einzutragen:
```
src/config.h
```

---

## Teilprojekte

| Ordner | Board | Funktion |
|---|---|---|
| `klappe_new/` | ESP32-S3-DevKitC-1-N16R8 | Hauptsteuerung Hühnerklappe |
| `bme280_sender/` | ESP32 DevKit | BME280-Sensor → ESP-NOW Sender |
| `relay_esp/` | ESP32-C3-DevKitM-1 | Relais-Node (ESP-NOW Empfänger) |
